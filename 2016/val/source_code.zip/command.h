#ifndef COMMAND_H
#define COMMAND_H

class Command {

	public :
		Command(void);
		~Command(void);

};

#endif // COMMAND_H
